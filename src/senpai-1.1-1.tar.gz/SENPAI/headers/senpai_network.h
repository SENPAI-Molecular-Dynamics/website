/*
 * senpai_network.h
 *
 * Licensed under GPLv3
 *
 */

#ifndef SENPAI_NETWORK_H
#define SENPAI_NETWORK_H

#define NET_IPV4_DEFAULT "0.0.0.0"
#define NET_PORT_DEFAULT 3301

#endif
